# Iqoption API

great robot
https://npt-life.com/iq-option-robot

Free version is late with private about 10 version

## Private version (Advance Support) 

* preview private version https://lu-yi-hsun.github.io/iqoptionapi_private/

* 250USD per month

* real time fix bug and support

* teach how to build your own product

* protect your product

* Build you own Copy trade product 3000usd

## HFT API

THIS PROJECT FOR SPECIAL HIGHT SPEED API

* 500 USD per month

* C+DPDK HIGHT SPEED API FOR arbitrage　or HFT

## Document

### New document

https://lu-yi-hsun.github.io/iqoptionapi/
 
### Old document

old document not support anymore:
https://github.com/Lu-Yi-Hsun/iqoptionapi_private/blob/master/old_document.md
